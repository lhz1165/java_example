package xxxx.xx;

public class AOutPut extends Output {

   @Override
    public void print(){
        System.out.println("aaaaaaa   out put");
    }

}
