package xxxx.xx;

public class BoutPut extends Output {

    @Override
    public void print() {
        System.out.println("Bbbb out put");
    }
}
