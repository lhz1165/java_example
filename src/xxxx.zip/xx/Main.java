package xxxx.xx;



public class Main {
    public static void main(String[] args) {
        Main main = new Main();

        Output outPut = new CoutPut();

        main.printAorB(outPut);

    }


    public void printAorB(Output outPut) {
        outPut.print();
    }
}
