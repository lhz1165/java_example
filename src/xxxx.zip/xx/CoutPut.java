package xxxx.xx;

public class CoutPut extends Output {
    @Override
    public void print() {
        System.out.println("cccccccccccccccccc");
    }



}
