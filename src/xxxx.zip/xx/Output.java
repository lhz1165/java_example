package xxxx.xx;

public class Output {

     void print(){
          System.out.println("ffffff");
     }

}
