package xxxx.xx2;

public class BoutPut implements Output {

    @Override
    public void print() {
        System.out.println("Bbbb out put");
    }
}
