package xxxx.xx2;

public class CoutPut implements Output {
    @Override
    public void print() {
        System.out.println("cccccccccccccccccc");
    }
}
