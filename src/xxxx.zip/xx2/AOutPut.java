package xxxx.xx2;

public class AOutPut implements Output {

   @Override
    public void print(){
        System.out.println("aaaaaaa   out put");
    }

}
