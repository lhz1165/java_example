package xxxx.xx2;

public interface Output {

     void print();

}
